CREATE TRIGGER update_products_timestamp
                            BEFORE UPDATE ON Products
                            FOR EACH ROW
                            BEGIN
                                UPDATE Products SET updated_at = datetime('now') WHERE id = NEW.id;
                            END;

