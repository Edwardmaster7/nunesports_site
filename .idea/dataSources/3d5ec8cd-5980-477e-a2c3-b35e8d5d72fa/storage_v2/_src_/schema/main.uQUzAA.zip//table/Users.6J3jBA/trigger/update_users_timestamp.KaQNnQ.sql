CREATE TRIGGER update_users_timestamp
          BEFORE UPDATE ON Users
          FOR EACH ROW
          BEGIN
            UPDATE Users SET updated_at = datetime('now') WHERE id = NEW.id;
          END;

